# SoilMate — Arduino Soil Monitoring and Fertilizer Guidance

SoilMate is a student prototype concept for monitoring soil moisture and NPK (nitrogen, phosphorus, potassium) readings and giving basic guidance about what to check next.

> **Prototype status:** This is a starter implementation and has not been field-validated. Sensor readings, calibration values, and recommendation thresholds must be verified for the actual sensors, soil type, crop, and local agronomic guidance. The example CSV contains illustrative data only.

## Features
- Reads soil moisture from an analog sensor.
- Reads N, P, and K inputs only if the selected modules provide compatible analog outputs.
- Prints readings and simple moisture prompts to the Serial Monitor.
- Includes example data, architecture notes, and manual test cases.

## Hardware assumptions
- Arduino Uno or compatible board.
- Analog soil-moisture sensor connected to `A0`.
- Compatible analog-output N/P/K modules connected to `A1`, `A2`, and `A3`.

**Important:** Many combined soil NPK sensors use RS485/Modbus. This sketch does not implement RS485/Modbus. If your sensor has A/B or RS485 terminals, follow its exact model documentation; do not connect it to A1–A3 as if it were an analog sensor.

## Wiring (analog-output modules only)
| Signal | Arduino pin |
|---|---|
| Soil moisture analog output | A0 |
| Nitrogen analog output | A1 |
| Phosphorus analog output | A2 |
| Potassium analog output | A3 |
| Module power and ground | Follow module datasheets; share ground where required |

Check sensor voltage ranges before connecting. Never apply a voltage above your Arduino board's input rating.

## Setup
1. Install the Arduino IDE: https://www.arduino.cc/en/software
2. Open `src/SoilMate.ino`.
3. Select your board and serial port in **Tools**.
4. Verify sensor pinout, voltage range, and output type using each datasheet.
5. Connect compatible analog-output modules according to the table.
6. Upload the sketch and open **Tools → Serial Monitor** at `9600 baud`.
7. Calibrate moisture using dry and wet reference samples. Update `MOISTURE_DRY_RAW` and `MOISTURE_WET_RAW` in the sketch.
8. Configure thresholds only using suitable crop/soil guidance. The included values are placeholders, not fertilizer prescriptions.

## Output and limitations
The sketch displays raw NPK ADC readings, **not validated mg/kg concentrations**. It does not calculate fertilizer quantity. Readings vary by sensor, soil texture, salinity, moisture, temperature, and calibration. Validate with a suitable reference method before making agricultural decisions. Keep electronics protected from water.

## Repository map
- `src/SoilMate.ino` — Arduino starter sketch.
- `docs/architecture.md` — architecture and data flow.
- `docs/setup-guide.md` — setup and calibration checklist.
- `data/sample_data.csv` — illustrative sample records, not real field data.
- `tests/test_cases.md` — proposed manual test plan.
- `LICENSE` — MIT License.

## Contributing
When reporting an issue, include the board model, sensor model, wiring, and observed output. Do not present unvalidated readings as verified results.

## License
MIT License. See `LICENSE`.
