# SoilMate Test Cases

These are proposed manual tests, not claims that the hardware has passed testing.

| ID | Test | Procedure | Expected result |
|---|---|---|---|
| TC-01 | Serial startup | Reset Arduino; open Serial Monitor at 9600 baud | Startup and safety notes appear |
| TC-02 | Periodic readings | Leave board running for at least 6 seconds | Readings appear roughly every 2 seconds |
| TC-03 | Moisture calibration | Set dry/wet constants to different calibration readings | Moisture estimate is constrained to 0–100% |
| TC-04 | Invalid calibration | Temporarily set dry and wet constants equal | Sketch reports calibration error |
| TC-05 | Low moisture prompt | Apply a condition mapping below configured low threshold | Low-moisture prompt appears |
| TC-06 | High moisture prompt | Apply a condition mapping above configured high threshold | High-moisture prompt appears |
| TC-07 | NPK raw display | Connect compatible analog-output modules or controlled test inputs | Raw ADC values are displayed |
| TC-08 | Sensor compatibility | Check sensor documentation before wiring | RS485/Modbus sensor is not connected as analog |
| TC-09 | Voltage check | Compare sensor output voltage to board input limits | No input exceeds board rating |
| TC-10 | Field validation | Compare readings with reference method and agronomic advice | Results documented before real use |

## Recording results
Record date, board model, sensor model, wiring, expected result, observed result, and pass/fail. Mark a test passed only after it has actually been performed.
