/*
  SoilMate — Arduino soil monitoring starter sketch
  Assumptions: moisture analog output on A0; compatible analog N/P/K modules on A1-A3.
  NPK values are raw ADC readings, not mg/kg.
  Many NPK sensors use RS485/Modbus; this sketch does NOT implement that protocol.
*/

const int MOISTURE_PIN = A0;
const int N_PIN = A1;
const int P_PIN = A2;
const int K_PIN = A3;

// Example calibration values only; calibrate with your actual sensor.
const int MOISTURE_DRY_RAW = 800;
const int MOISTURE_WET_RAW = 350;

// Placeholder display thresholds, not agronomic prescriptions.
const int MOISTURE_LOW_PERCENT = 30;
const int MOISTURE_HIGH_PERCENT = 80;
const unsigned long READ_INTERVAL_MS = 2000;
unsigned long lastReadMs = 0;

int readAverage(int pin, int samples = 10) {
  long total = 0;
  for (int i = 0; i < samples; i++) {
    total += analogRead(pin);
    delay(5);
  }
  return (int)(total / samples);
}

int moisturePercentFromRaw(int raw) {
  if (MOISTURE_DRY_RAW == MOISTURE_WET_RAW) return -1;
  long pct = (long)(MOISTURE_DRY_RAW - raw) * 100L /
             (MOISTURE_DRY_RAW - MOISTURE_WET_RAW);
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  return (int)pct;
}

void printMoisturePrompt(int moisturePct) {
  if (moisturePct < 0) {
    Serial.println(F("Moisture calibration error: dry and wet values must differ."));
  } else if (moisturePct < MOISTURE_LOW_PERCENT) {
    Serial.println(F("Prompt: soil appears dry; check crop needs before watering."));
  } else if (moisturePct > MOISTURE_HIGH_PERCENT) {
    Serial.println(F("Prompt: soil appears very wet; check drainage and crop needs."));
  } else {
    Serial.println(F("Prompt: moisture is within the configured example range."));
  }
}

void setup() {
  Serial.begin(9600);
  Serial.println(F("SoilMate Arduino prototype starting..."));
  Serial.println(F("NPK values are raw ADC readings, not mg/kg."));
  Serial.println(F("Check sensor compatibility and calibrate before use."));
}

void loop() {
  unsigned long now = millis();
  if (now - lastReadMs >= READ_INTERVAL_MS) {
    lastReadMs = now;
    int moistureRaw = readAverage(MOISTURE_PIN);
    int nRaw = readAverage(N_PIN);
    int pRaw = readAverage(P_PIN);
    int kRaw = readAverage(K_PIN);
    int moisturePct = moisturePercentFromRaw(moistureRaw);

    Serial.println(F("\n--- SoilMate Reading ---"));
    Serial.print(F("Moisture raw: ")); Serial.println(moistureRaw);
    Serial.print(F("Estimated moisture (%; requires calibration): "));
    if (moisturePct < 0) Serial.println(F("invalid"));
    else Serial.println(moisturePct);
    Serial.print(F("Nitrogen input raw ADC: ")); Serial.println(nRaw);
    Serial.print(F("Phosphorus input raw ADC: ")); Serial.println(pRaw);
    Serial.print(F("Potassium input raw ADC: ")); Serial.println(kRaw);
    printMoisturePrompt(moisturePct);
    Serial.println(F("NPK prompt: use calibrated sensor units and crop-specific guidance."));
    Serial.println(F("No fertilizer quantity is calculated by this starter sketch."));
  }
}
