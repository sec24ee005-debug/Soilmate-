# SoilMate Setup and Calibration Guide

## Before powering on
- Identify the exact Arduino board and sensor models.
- Read datasheets for pinout, voltage, output type, and power needs.
- Confirm whether the NPK sensor is analog-output or RS485/Modbus.
- Ensure grounds are wired as required.
- Never apply voltage above the Arduino input rating.

## Upload
1. Install Arduino IDE from https://www.arduino.cc/en/software
2. Open `src/SoilMate.ino`.
3. Select the correct board and serial port.
4. Upload the sketch.
5. Open Serial Monitor at 9600 baud.

## Moisture calibration
1. Record raw reading in a dry reference condition.
2. Record raw reading in a suitably wet reference condition.
3. Replace `MOISTURE_DRY_RAW` and `MOISTURE_WET_RAW` in the sketch.
4. Repeat measurements to check stability.
5. Validate the percentage against a suitable reference method before relying on it.

## NPK integration
The sketch reads A1-A3 only for modules that explicitly provide compatible analog outputs. If your sensor uses RS485/Modbus, do not use this analog setup. Obtain the exact model, protocol/register map, and required transceiver before implementing that interface.

## Thresholds
Moisture limits are example values for software demonstration. Set thresholds for crop, growth stage, soil type, and irrigation practice. Do not use raw NPK ADC readings to determine fertilizer dosage.
