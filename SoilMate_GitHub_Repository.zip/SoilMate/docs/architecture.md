# SoilMate Architecture

## Purpose
SoilMate is a prototype for collecting soil sensor readings and displaying basic prompts.

## Data flow
1. **Sensors:** moisture sensor and, where compatible, N/P/K modules.
2. **Input:** Arduino analog inputs sample voltage levels using `analogRead()`.
3. **Processing:** the sketch averages several readings and maps moisture using calibration values.
4. **Guidance:** a configured moisture range produces a basic prompt. NPK values are displayed as raw ADC values only.
5. **Output:** readings are shown in the Arduino Serial Monitor.

```text
Soil Moisture Sensor ── A0 ┐
N module (analog only) ─ A1 ├──> Arduino ──> Serial Monitor
P module (analog only) ─ A2 ┤       └────> Basic moisture prompt
K module (analog only) ─ A3 ┘
```

## Interface boundary
An RS485/Modbus NPK sensor requires a compatible transceiver, protocol handling, and sensor-specific register mapping. That integration is not included because the exact sensor model has not been specified.

## Current limitations
- No wireless/cloud dashboard or data storage.
- No validated NPK conversion to concentration units.
- No fertilizer-dose calculation.
- Thresholds are placeholders and need calibration and agronomic input.
- The design has not been field-validated.
